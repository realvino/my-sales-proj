﻿export class Month {
    private val: string;
    private name: string;
}