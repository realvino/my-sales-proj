import { Component, ViewChild, Injector, ElementRef, Output, EventEmitter, OnInit } from '@angular/core';
import { AppComponentBase } from '@shared/common/app-component-base';
import { EnquiryServiceProxy,EnquiryList,ActivityServiceProxy,ActivityListDto } from '@shared/service-proxies/service-proxies';
import { Router,ActivatedRoute,NavigationEnd } from "@angular/router";
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { DataTable } from 'primeng/components/datatable/datatable';
import { Paginator } from 'primeng/components/paginator/paginator';
import { LazyLoadEvent } from 'primeng/components/common/lazyloadevent';
import {CreateActivityComponent} from './createActivity.component';
import { DatePipe } from '@angular/common';

export interface SelectOption {
    id?: number;
    text?: string;
}


@Component({
    templateUrl: './editEnquiry.component.html',
    styleUrls: ['./editEnquiry.component.css'],
    animations: [appModuleAnimation()]
})
export class EditEnquiryComponent extends AppComponentBase implements OnInit {
   
    active = false;
    saving = false;
    enquiry_detail:EnquiryList= new EnquiryList();
    private sub: any;
    private id: number;
    filterText: string = '';
    records:ActivityListDto[]=[];

    @ViewChild('dataTable') dataTable: DataTable;
    @ViewChild('paginator') paginator: Paginator;
    @ViewChild('createEActivityModal') createEActivityModal: CreateActivityComponent;
    constructor(
        injector: Injector,
        private router: Router,
        private _activatedRoute: ActivatedRoute,
        private _enquiryService: EnquiryServiceProxy,
        private _activityService:ActivityServiceProxy
    ) {
        super(injector);
        
    }
    ngOnInit(){
        this.sub = this._activatedRoute.params.subscribe(params => {
           this.id = +params['id']; // (+) converts string 'id' to a number
           this.getAllEnquiryDetail();
            this.getData();
        });

    }
    show(): void {

        //this.modal.show();
        this.active= true;
        this.getData();

    }
    getAllEnquiryDetail(){
        this._enquiryService.getEnquiryForEdit(this.id).subscribe(result=>{
            if(result.enquiryDetail!=null){
                this.enquiry_detail = result.enquiryDetail;
                console.log(this.enquiry_detail);
            }
        });
    }


    save(): void {
        this.saving = false;
        this.close();

    }
    onShown(): void {
        //$(this.nameInput.nativeElement).focus();
    }
    close(): void {
        var locat = this.router.url.slice(0, -1);
        this.router.navigate([locat]);
        this.active = false;
    }

    getData(event?: LazyLoadEvent): void {

        this._activityService.getEnquiryWiseActivity(this.id)
            .subscribe((result) => {
               this.records=result.items;

            });

    }

    createActivity(){
        this.createEActivityModal.show(this.enquiry_detail,0);
    }
    editAct(data){
        this.createEActivityModal.show(this.enquiry_detail,data.id);
    }


    deleteAct(record): void {
        this.message.confirm(
            this.l('Are you sure to Delete the Activity'),
                isConfirmed => {
                if (isConfirmed) {
                      this._activityService.getDeleteActivity(record.id).subscribe(result=>{
                     if(result)
                     {
                     this.notify.error(this.l('This could not be deleted'));
                     }else{
                         this.getData();
                     }
                     });
                }
            });
    }




}