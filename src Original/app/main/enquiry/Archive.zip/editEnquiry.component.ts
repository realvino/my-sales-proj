import { Component, ViewChild, Injector, ElementRef, Output, EventEmitter, OnInit } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap';
import { AppComponentBase } from '@shared/common/app-component-base';
// import { CompanyContactServiceProxy,CreateCompanyOrContact } from '@shared/service-proxies/service-proxies';
// import { Select2ServiceProxy,Datadto } from "shared/service-proxies/service-proxies";
import { Router,ActivatedRoute,NavigationEnd } from "@angular/router";
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { ActivityCreationComponent } from './createActivity.component';
export interface SelectOption {
    id?: number;
    text?: string;
}


@Component({
    templateUrl: './editEnquiry.component.html',
    styleUrls: ['./editEnquiry.component.css'],
    animations: [appModuleAnimation()]
})
export class EditEnquiryComponent extends AppComponentBase implements OnInit {

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();
     @ViewChild('modal') modal: ModalDirective;
     @ViewChild('nameInput') nameInput: ElementRef;
    @ViewChild('ActivityCreation') ActivityCreation: ActivityCreationComponent;
   
    active = false;
    saving = false;

    constructor(
        injector: Injector,
        private router: Router,
        private _activatedRoute: ActivatedRoute
        // private _selectProxyService: Select2ServiceProxy
    ) {
        super(injector);
        
    }
    ngOnInit(){
        
    }
    show(): void {

        //this.modal.show();
        this.active= true;

    }



    save(): void {
        this.saving = false;
        this.close();

    }
    onShown(): void {
        //$(this.nameInput.nativeElement).focus();
    }
    close(): void {
        var locat = this.router.url.slice(0, -1);
        this.router.navigate([locat]);
        this.active = false;
    }

    createActivitybyEnq():void{
        this.ActivityCreation.show(0);
    }
}